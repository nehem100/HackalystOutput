<form>

Year: <input type="text" name="year"><br> <!--iyear, emyr-->
Variety: <input type="text" name="variety">
Day of Sowing <input type="text" name="day"> <!--sttime, emd-->
Seeding: <input type="text" name="estab">
Duration: <input type="text" name="sbdur">

<input type="submit" value="START" name="submit">
</form>
