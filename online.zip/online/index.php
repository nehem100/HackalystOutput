<?php
include ('_include/connect.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Welcome to Oryza2000 Online!</title>
	<script language="JavaScript" src="_js/htmlDatePicker.js" type="text/javascript"></script>
		<link href="_design/htmlDatePicker.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="_design/style.css" media="screen" />
	<script>
		window.onload=function()
			{
				var select=document.getElementById('seeding');
				var inps1=document.getElementById('SelectedDate');
				var inps2=document.getElementById('trans2');
				select.onchange=function()
				{
					if(/^TRANSPLANT*$/.test(select.value)){
						inps1.disabled = false
						inps1.style.display="block"
						inps2.style.display="block"
						
					}else{
						inps1.disabled = true
						inps1.style.display="none"
						inps2.style.display="none"

					}

				}
				
				
			}
	</script>

</head>
<body>
<div id="main_container">
    <div id="logo">
		<table cellpadding="0" cellspacing="0">
			<tr>
				<td>
					<img style="height:75px;" src="_design/images/log.jpg" alt="" title="" border="0" />
				</td>
			</tr>
		</table>	
	</div>
	<div id="line" ></div>
    <div class="content">
		<table border="0"style="width:100%;" cellpadding="10">
			<tr>
				<td style="width:15%;" valign="top">
					<img src="_design/images/graph-icon.png" alt="" title="" width="200" height="auto" />    
				</td>
				<td style="width:35%;" valign="top">
					<!-------FORM---------->
					<div >
		<div >
			
				<?php
					if(!empty($_GET['content']) AND $_GET['content']=="1"){
						$class = "out_active";
					}
					else
					{
						if(empty($_GET['content'])){
						$class = "out_active";
						}
						else
						{
						$class = "out";
						}
					}
					
					if(!empty($_GET['content']) AND $_GET['content']=="2"){
						$class1 = "out_active";
					}
					else
					{
						$class1 = "out";
					}
				?>
				
				&emsp;<a class="<?php echo $class?>" href="?content=1" >GROWTH SIMULATION</a>&emsp; 
				<a class="<?php echo $class1?>" href="?content=2" >POTENTIAL YIELD</a>&emsp; 
			
		</div>
		<div style="height:1px;background-color:green;">			
		</div>
	</div>
	<div style="padding-left:25px;border-left:green solid 1px;background-color:white;">
	<br>
					<?php
						if(!empty($_GET['content']) AND $_GET['content']=="2"){
							include("_include/form_potential.php");
						}
							else
						{
							include("_include/form_simulator.php");
						}
					?>
	</div>
				</td>
				<td valign="top">
					
					<h2 class="label">OryzaOnline: A Rice Plant Growth Simulation Tool under Potential Environment</h2>
					<p style="color:gray;padding-left:15px;border-left:1px solid green;">                                        
					ORYZA2000 is a crop modeling tool used to simulate the growth, development, and water balance of lowland rice under conditions of potential production, and water- and/or nitrogen-limitations. It was calibrated and validated for 18 popular rice varieties in 15 locations throughout Asia.
					<br /><br />

					The modeling group in International Rice Research Institute encourages tests and applications of ORYZA2000 and welcomes feedback. The modeling group also provides minor tech support to users. 
					<br /> 
					
			</p>
				</td>
			</tr>
		</table>
	</div>	
   <div style="margin:auto;width:98%;height:1px;background-color:green;">			
		</div>
    <div class="content1">
        <h2 class="label">Simulation Results</h2> 
						<?php
						if(!empty($_GET['content']) AND $_GET['content']=="2"){
							echo "<h1>For Further Development</h1>";
						}
							else
						{
							include("_include/submit1.php");
						 }
					?> 
    
    </div><!--end of main content-->
	<div id="line1" ></div>	
</div> <!--end of main container-->
</body>
</html>
