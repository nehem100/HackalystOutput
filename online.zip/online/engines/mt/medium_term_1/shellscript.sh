cd /var/www/online/engines/mt/medium_term_1/
./oryza2000.exe control.dat


