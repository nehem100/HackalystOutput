cd /var/www/online/engines/mt/medium_term_2/
./oryza2000.exe control.dat


