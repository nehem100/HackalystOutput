cd /var/www/online/engines/st/short_term_1/
./oryza2000.exe control.dat


