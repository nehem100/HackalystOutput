cd /var/www/online/engines/st/short_term_2/
./oryza2000.exe control.dat


