cd /var/www/online/engines/lt/long_term_2/
./oryza2000.exe control.dat


