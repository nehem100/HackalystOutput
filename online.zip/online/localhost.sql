-- phpMyAdmin SQL Dump
-- version 3.3.7deb7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 11, 2013 at 09:47 AM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-7+squeeze14

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `Simulation`
--
CREATE DATABASE `Simulation` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `Simulation`;

-- --------------------------------------------------------

--
-- Table structure for table `lt_engines`
--

CREATE TABLE IF NOT EXISTS `lt_engines` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `path` varchar(50) NOT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `lt_engines`
--

INSERT INTO `lt_engines` (`id`, `path`, `status`) VALUES
(1, '/var/www/online/engines/lt/long_term_1/', 0),
(2, '/var/www/online/engines/lt/long_term_2/', 0),
(3, '/var/www/online/engines/lt/long_term_3/', 0),
(4, '/var/www/online/engines/lt/long_term_4/', 0),
(5, '/var/www/online/engines/lt/long_term_5/', 0),
(6, '/var/www/online/engines/lt/long_term_6/', 0),
(7, '/var/www/online/engines/lt/long_term_7/', 0),
(8, '/var/www/online/engines/lt/long_term_8/', 0),
(9, '/var/www/online/engines/lt/long_term_9/', 0),
(10, '/var/www/online/engines/lt/long_term_10/', 0);

-- --------------------------------------------------------

--
-- Table structure for table `mt_engines`
--

CREATE TABLE IF NOT EXISTS `mt_engines` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `path` varchar(50) NOT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `mt_engines`
--

INSERT INTO `mt_engines` (`id`, `path`, `status`) VALUES
(1, '/var/www/online/engines/mt/medium_term_1/', 0),
(2, '/var/www/online/engines/mt/medium_term_2/', 0),
(3, '/var/www/online/engines/mt/medium_term_3/', 0),
(4, '/var/www/online/engines/mt/medium_term_4/', 0),
(5, '/var/www/online/engines/mt/medium_term_5/', 0),
(6, '/var/www/online/engines/mt/medium_term_6/', 0),
(7, '/var/www/online/engines/mt/medium_term_7/', 0),
(8, '/var/www/online/engines/mt/medium_term_8/', 0),
(9, '/var/www/online/engines/mt/medium_term_9/', 0),
(10, '/var/www/online/engines/mt/medium_term_10/', 0);

-- --------------------------------------------------------

--
-- Table structure for table `st_engines`
--

CREATE TABLE IF NOT EXISTS `st_engines` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `path` varchar(50) NOT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `st_engines`
--

INSERT INTO `st_engines` (`id`, `path`, `status`) VALUES
(1, '/var/www/online/engines/st/short_term_1/', 0),
(2, '/var/www/online/engines/st/short_term_2/', 0),
(3, '/var/www/online/engines/st/short_term_3/', 0),
(4, '/var/www/online/engines/st/short_term_4/', 0),
(5, '/var/www/online/engines/st/short_term_5/', 0),
(6, '/var/www/online/engines/st/short_term_6/', 0),
(7, '/var/www/online/engines/st/short_term_7/', 0),
(8, '/var/www/online/engines/st/short_term_8/', 0),
(9, '/var/www/online/engines/st/short_term_9/', 0),
(10, '/var/www/online/engines/st/short_term_10/', 0);
