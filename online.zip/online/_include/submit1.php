<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
include ('_include/connect.php');
function select_engine(){
$variety = "haha";
if (isset($_POST['variety'])){
	if ($_POST['variety'] == "st_engines"){
	$variety = "short_term";
	} 
	else if ($_POST['variety'] == "mt_engines"){
	$variety = "medium_term";
	} 
	else if ($_POST['variety'] == "lt_engines"){
	$variety = "long_term";
	} 
};
//echo $_POST['variety'];
$run = 0;
$engine_id = 0;
while($run == 0){
	$result = mysql_query("SELECT min(id) FROM $_POST[variety] WHERE status = 0");
	while($row = mysql_fetch_array($result)){
			$engine_id = $row['min(id)'];
			}
	if ($engine_id != NULL){
		//echo "GUSTO";
		mysql_query("UPDATE $_POST[variety] SET status=1 WHERE id = $engine_id");
		$result = mysql_query("SELECT path FROM $_POST[variety] WHERE id = $engine_id");
		while($row = mysql_fetch_array($result)){
			$path = $row['path'];
			}
		$_POST['engine_id'] = $engine_id;
		//echo $variety."<br>";
		//echo $path.''.$variety.'.exp';
		process($path, $variety);
		file_put_contents($path.'reruns.dat', '');
		file_put_contents($path.'op.dat', '');
		$out = shell_exec($path."shellscript.sh");
		//echo $out;	
		return $path;
		break;   
		}
	else{
		//echo "AYAW";
		//echo $engine_id;		
		sleep(2);
		break;
		}
	}
}

function process($path, $variety){
	$iyear = "IYEAR= ".$_POST['year']."                ! start year of simulation (year)\r\n";
	
	$year = $_POST['year'];
	$temp = $_POST['day'];
	$newSowDate = date("z", strtotime($temp."/".$year)) + 1;

	$sttime = "STTIME =  ".$newSowDate.".               ! start time (day numer)\r\n";
	if ($_POST['estab'] == "DIRECT-SEED"){
	$estab = "ESTAB='DIRECT-SEED'\r\n";
	$sbdur = "SBDUR=   0    ! seed-bed duration (days)\r\n";
	}
	else if ($_POST['estab'] == "TRANSPLANT"){
	$estab = "ESTAB='TRANSPLANT'\r\n";
	$sbdur = "SBDUR=   ".$_POST['sbdur']."    ! seed-bed duration (days)\r\n";
	}
	$emd = "EMD=   ".$newSowDate."    ! Day of emergence (either direct, or in seed-bed)\r\n";
	$emyr = "EMYR= ".$_POST['year']."    ! Year of emergence (1996)\r\n";
	
	$reading = fopen($path.''.$variety.'.exp', 'r');
	$writing = fopen($path.''.$variety.'.tmp', 'w');

	$replaced = false;
	while (!feof($reading)) {
	  $line = fgets($reading);
	  if (stristr($line,'IYEAR')) {
		$line = $iyear;
		$replaced = true;
	  }
	  else if (stristr($line,'STTIME')) {
		$line = $sttime;
		$replaced = true;
	  }
	  else if (stristr($line,'ESTAB=')) {
		$line = $estab;
		$replaced = true;
	  }
	  else if (stristr($line,'EMD')) {
		$line = $emd;
		$replaced = true;
	  }
	  else if (stristr($line,'EMYR')) {
		$line = $emyr;
		$replaced = true;
	  }
	  else if (stristr($line,'SBDUR')) {
		$line = $sbdur;
		$replaced = true;
	  }
	  fputs($writing, $line);
	}

	fclose($reading); fclose($writing);

	if ($replaced) 
	{
	  rename($path.''.$variety.'.tmp', $path.''.$variety.'.exp');
	} else {
	  unlink($path.''.$variety.'.tmp');
	}
}
?>


<script type="text/javascript" src="_js/jquery.min.js"></script>

<?php 
function graph($n_arr){
if ($_POST['variety'] == "st_engines"){
	$variety2 = "SHORT TERM";
	} 
	else if ($_POST['variety'] == "mt_engines"){
	$variety2 = "MEDIUM TERM";
	} 
	else if ($_POST['variety'] == "lt_engines"){
	$variety2 = "LONG TERM";
	} 
if ($_POST['estab'] == "DIRECT-SEED"){
	$sbdur = "0";
	}
else{
	$sbdur = $_POST['sbdur'];
}
?>
<script type="text/javascript">
$(function () {
        $('.container').highcharts({
            title: {
                text: 'PLANT GROWTH SIMULATION RESULT',
                x: -20 //center
            },
            subtitle: {
                text: 'Year: <?php echo $_POST['year'];?>; Variety: <?php echo $variety2;?>; Day of Sowing: <?php echo $_POST['day'];?>; Seeding: <?php echo $_POST['estab'];?>; Duration in Seedbed: <?php echo $sbdur;?> days',
                x: -20
            },
            xAxis: {
                categories: [ <?php $count = count($n_arr);
				for ($ctr = 0; $ctr < $count; $ctr++)
				{ 
				print_r($n_arr[$ctr][1]);
				echo ","; 
				}
				?>
					0]
            },
            yAxis: {
                title: {
                    text: ''
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: ''
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: 'Dry Weight of Rough Rice (14% Moisture)',
                data: [ 
			<?php 
			$count = count($n_arr);
			for ($ctr = 0; $ctr < $count; $ctr++)
			{ 
			print_r($n_arr[$ctr][23]);
			echo ", "; 
			}
			?> 
			]
            }]
        });
    });
$(function () {
        $('.container6').highcharts({
            title: {
                text: 'PLANT GROWTH SIMULATION RESULT',
                x: -20 //center
            },
            subtitle: {
                text: 'Year: <?php echo $_POST['year'];?>; Variety: <?php echo $variety2;?>; Day of Sowing: <?php echo $_POST['day'];?>; Seeding: <?php echo $_POST['estab'];?>; Duration in Seedbed: <?php echo $sbdur;?> days',
                x: -20
            },
            xAxis: {
                categories: [ <?php $count = count($n_arr);
				for ($ctr = 0; $ctr < $count; $ctr++)
				{ 
				print_r($n_arr[$ctr][1]);
				echo ","; 
				}
				?>
					0]
            },
            yAxis: {
                title: {
                    text: ''
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: ''
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: 'Crop Stage',
                data: [ 
			<?php 
			$count = count($n_arr);
			for ($ctr = 0; $ctr < $count; $ctr++)
			{ 
			print_r($n_arr[$ctr][26]);
			echo ", "; 
			}
			?> 
			]
            }]
        });
    });
$(function () {
        $('.container2').highcharts({
            title: {
                text: 'PLANT GROWTH SIMULATION RESULT',
                x: -20 //center
            },
            subtitle: {
                text: 'Year: <?php echo $_POST['year'];?>; Variety: <?php echo $variety2;?>; Day of Sowing: <?php echo $_POST['day'];?>; Seeding: <?php echo $_POST['estab'];?>; Duration in Seedbed: <?php echo $sbdur;?> days',
                x: -20
            },
            xAxis: {
                categories: [ <?php $count = count($n_arr);
				for ($ctr = 0; $ctr < $count; $ctr++)
				{ 
				print_r($n_arr[$ctr][1]);
				echo ","; 
				}
				?>
					0]
            },
            yAxis: {
                title: {
                    text: ''
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: ''
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: 'Number of Spikelets',
                data: [ 
			<?php 
			$count = count($n_arr);
			for ($ctr = 0; $ctr < $count; $ctr++)
			{ 
			print_r($n_arr[$ctr][14]);
			echo ", "; 
			}
			?> 
			]
            }]
        });
    });
$(function () {
        $('.container3').highcharts({
            title: {
                text: 'PLANT GROWTH SIMULATION RESULT',
                x: -20 //center
            },
            subtitle: {
                text: 'Year: <?php echo $_POST['year'];?>; Variety: <?php echo $variety2;?>; Day of Sowing: <?php echo $_POST['day'];?>; Seeding: <?php echo $_POST['estab'];?>; Duration in Seedbed: <?php echo $sbdur;?> days',
                x: -20
            },
            xAxis: {
                categories: [ <?php $count = count($n_arr);
				for ($ctr = 0; $ctr < $count; $ctr++)
				{ 
				print_r($n_arr[$ctr][1]);
				echo ","; 
				}
				?>
					0]
            },
            yAxis: {
                title: {
                    text: ''
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: ''
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: 'Maximum Temperature',
                data: [ 
			<?php 
			$count = count($n_arr);
			for ($ctr = 0; $ctr < $count; $ctr++)
			{ 
			print_r($n_arr[$ctr][4]);
			echo ", "; 
			}
			?> 
			]
            }]
        });
    });
$(function () {
        $('.container4').highcharts({
            title: {
                text: 'PLANT GROWTH SIMULATION RESULT',
                x: -20 //center
            },
            subtitle: {
                text: 'Year: <?php echo $_POST['year'];?>; Variety: <?php echo $variety2;?>; Day of Sowing: <?php echo $_POST['day'];?>; Seeding: <?php echo $_POST['estab'];?>; Duration in Seedbed: <?php echo $sbdur;?> days',
                x: -20
            },
            xAxis: {
                categories: [ <?php $count = count($n_arr);
				for ($ctr = 0; $ctr < $count; $ctr++)
				{ 
				print_r($n_arr[$ctr][1]);
				echo ","; 
				}
				?>
					0]
            },
            yAxis: {
                title: {
                    text: ''
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: ''
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: 'Minimum Temperature',
                data: [ 
			<?php 
			$count = count($n_arr);
			for ($ctr = 0; $ctr < $count; $ctr++)
			{ 
			print_r($n_arr[$ctr][3]);
			echo ", "; 
			}
			?> 
			]
            }]
        });
    });
$(function () {
        $('.container5').highcharts({
            title: {
                text: 'PLANT GROWTH SIMULATION RESULT',
                x: -20 //center
            },
            subtitle: {
                text: 'Year: <?php echo $_POST['year'];?>; Variety: <?php echo $variety2;?>; Day of Sowing: <?php echo $_POST['day'];?>; Seeding: <?php echo $_POST['estab'];?>; Duration in Seedbed: <?php echo $sbdur;?> days',
                x: -20
            },
            xAxis: {
                categories: [ <?php $count = count($n_arr);
				for ($ctr = 0; $ctr < $count; $ctr++)
				{ 
				print_r($n_arr[$ctr][1]);
				echo ","; 
				}
				?>
					0]
            },
            yAxis: {
                title: {
                    text: ''
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: ''
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: 'Dry Weight of Leaves',
                data: [ 
			<?php 
			$count = count($n_arr);
			for ($ctr = 0; $ctr < $count; $ctr++)
			{ 
			print_r($n_arr[$ctr][21]);
			echo ", "; 
			}
			?> 
			]
            }]
        });
    });
</script>
<?php
}
?>
</head>
</body>
<script src="_js/highcharts.js"></script>
<script src="_js/modules/exporting.js"></script>
<div class="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
<div class="container6" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
<div class="container2" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
<div class="container3" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
<div class="container4" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
<div class="container5" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
<?php
echo "test";
if (isset($_POST['simulate']))
	{
	$path = select_engine();
	}
if (isset($path)){
	$reading = file_get_contents($path.'res.dat', true);

	$n = explode("\n", $reading); 
	$arr = $n;
	$i = -1 ;
	$count = 0;
	foreach($n as $line)
		{  
			if(0 === strpos($line, "   "))
			{
				if (strlen($line)>1){
				$i=$i+1;
				$arr[$i] = $line;
				$arr1 = explode("\t",$arr[$i]); 
				$j = 0;
				foreach($arr1 as $arr_line)
					{
					$j=$j + 1;
					$str = "$arr_line";
					if (preg_match('/E/', $str, $matches, PREG_OFFSET_CAPTURE, 1) == 1){
						$cut = explode("E", $str);
						$str = " ".pow($cut[0],$cut[1]);
						$n_arr[$i][$j] = $str;
					}
					else
					{
					$str = str_replace("-", '0', $arr_line);
					$n_arr[$i][$j] = $str;
					}
					//print_r($n_arr[$i][$j]);
					}
				//echo "<br>";
				}
			}
		}
	graph($n_arr);
	mysql_query("UPDATE ".$_POST['variety']." SET status=0 WHERE id = $_POST[engine_id]");
	file_put_contents($path.'reruns.dat', '');
	file_put_contents($path.'op.dat', '');
	}
?>
</body>
</html>
