<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
include ('../_include/connect.php');

function select_engine(){
$variety = "haha";
if (isset($_POST['variety'])){
	if ($_POST['variety'] == "st_engines"){
	$variety = "short_term";
	} 
	else if ($_POST['variety'] == "mt_engines"){
	$variety = "medium_term";
	} 
	else if ($_POST['variety'] == "lt_engines"){
	$variety = "long_term";
	} 
};
$run = 0;
$engine_id = 0;
while($run == 0){
	$result = mysql_query("SELECT min(id) FROM $_POST[variety] WHERE status = 0");
	while($row = mysql_fetch_array($result)){
			$engine_id = $row['min(id)'];
			}
	if ($engine_id != NULL){
		echo "GUSTO";
		mysql_query("UPDATE $_POST[variety] SET status=1 WHERE id = $engine_id");
		$result = mysql_query("SELECT path FROM $_POST[variety] WHERE id = $engine_id");
		while($row = mysql_fetch_array($result)){
			$path = $row['path'];
			}
		$_POST['engine_id'] = $engine_id;
		echo $variety."<br>";
		echo $path.''.$variety.'.exp';
		process($path, $variety);
		$out = shell_exec($path."shellscript.sh");
		echo $out;	
		return $path;
		break;   
		}
	else{
		echo "AYAW";		
		sleep(2);
		break;
		}
	}
}

function process($path, $variety){
	$iyear = "IYEAR= ".$_POST['year']."                ! start year of simulation (year)\r\n";
	$sttime = "STTIME =  ".$_POST['day'].".               ! start time (day numer)\r\n";
	if ($_POST['estab'] == "DIRECT-SEED"){
	$estab = "ESTAB='DIRECT-SEED'\r\n";
	$sbdur = "SBDUR=   0    ! seed-bed duration (days)\r\n";
	}
	else if ($_POST['estab'] == "TRANSPLANT"){
	$estab = "ESTAB='TRANSPLANT'\r\n";
	$sbdur = "SBDUR=   ".$_POST['sbdur']."    ! seed-bed duration (days)\r\n";
	}
	$emd = "EMD=   ".$_POST['day']."    ! Day of emergence (either direct, or in seed-bed)\r\n";
	$emyr = "EMYR= ".$_POST['year']."    ! Year of emergence (1996)\r\n";
	
	$reading = fopen($path.''.$variety.'.exp', 'r');
	$writing = fopen($path.''.$variety.'.tmp', 'w');

	$replaced = false;
	while (!feof($reading)) {
	  $line = fgets($reading);
	  if (stristr($line,'IYEAR')) {
		$line = $iyear;
		$replaced = true;
	  }
	  else if (stristr($line,'STTIME')) {
		$line = $sttime;
		$replaced = true;
	  }
	  else if (stristr($line,'ESTAB=')) {
		$line = $estab;
		$replaced = true;
	  }
	  else if (stristr($line,'EMD')) {
		$line = $emd;
		$replaced = true;
	  }
	  else if (stristr($line,'EMYR')) {
		$line = $emyr;
		$replaced = true;
	  }
	  else if (stristr($line,'SBDUR')) {
		$line = $sbdur;
		$replaced = true;
	  }
	  fputs($writing, $line);
	}

	fclose($reading); fclose($writing);

	if ($replaced) 
	{
	  rename($path.''.$variety.'.tmp', $path.''.$variety.'.exp');
	} else {
	  unlink($path.''.$variety.'.tmp');
	}
}
?>


<script type="text/javascript" src="../_js/jquery.min.js"></script>

<?php 
function graph($n_arr){
?>
<script type="text/javascript">
$(function () {
        $('#container').highcharts({
            title: {
                text: 'Monthly Average Temperature',
                x: -20 //center
            },
            subtitle: {
                text: 'Source: WorldClimate.com',
                x: -20
            },
            xAxis: {
                categories: [ <?php $count = count($n_arr);
					for ($ctr = 0; $ctr < $count; $ctr++)
					{ 
					print_r($n_arr[$ctr][1]);
					echo ","; 
					}
				?>
					0]
            },
            yAxis: {
                title: {
                    text: 'Temperature (°C)'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: '°C'
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: 'WRR14',
                data: [ <?php 
			$count = count($n_arr);
			for ($ctr = 0; $ctr < $count; $ctr++)
			{ 
			print_r($n_arr[$ctr][23]);
			echo ", "; 
			}
			?> ]
            },{
		name: 'This',
		data: [1,2,3,4,5,6,7,8,9,0]
		}]
        });
    });
	
</script>
<?php
}
?>
</head>
</body>
<?php
if (isset($_POST['simulate']))
	{
	$path = select_engine();
	}
if (isset($path)){
	$reading = file_get_contents($path.'res.dat', true);

	$n = explode("\n", $reading); 
	$arr = $n;
	$i = -1 ;
	$count = 0;
	foreach($n as $line)
		{  
			if(0 === strpos($line, "   "))
			{
				if (strlen($line)>1){
				$i=$i+1;
				$arr[$i] = $line;
				$arr1 = explode("\t",$arr[$i]); 
				$j = 0;
				foreach($arr1 as $arr_line)
					{
					$j=$j + 1;
					$str = "$arr_line";
					if (preg_match('/E/', $str, $matches, PREG_OFFSET_CAPTURE, 1) == 1){
						$cut = explode("E", $str);
						$str = " ".pow($cut[0],$cut[1]);
						$n_arr[$i][$j] = $str;
					}
					else
					{
					$str = str_replace("-", '0', $arr_line);
					$n_arr[$i][$j] = $str;
					}
					//print_r($n_arr[$i][$j]);
					}
				//echo "<br>";
				}
			}
		}
	graph($n_arr);
	mysql_query("UPDATE ".$_POST['variety']." SET status=0 WHERE id = $_POST[engine_id]");
	}
?>
<script src="../_js/highcharts.js"></script>
<script src="../_js/modules/exporting.js"></script>
<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
</body>
</html>
