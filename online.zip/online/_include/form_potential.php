	<h2 class="label">Yield Potential</h2>
						<form id="ff" action="index.php?content=2" method="post" >
						<table style="width:100%;" border="0">
						<tr>
							<td bgcolor="#afdf6b">Year:</td>
							<td><select name="year" style="width:100%;border:1px solid green;padding:5px;">
								
								<?php
								for($i=1990;$i<=2006;$i++){
								
								echo "<option value=".$i.">".$i."</option>";
								
								}
								
								?>
								
								</select></td>
						</tr>
						<tr>
							<td bgcolor="#afdf6b">Variety:</td>
							<td>
								<select style="width:100%;border:1px solid green;padding:5px;" name="variety">
									<option >--Select Variety--</option>
									<option value="st_engines">Short Term</option>
									<option value="mt_engines">Medium Term </option>
									<option value="lt_engines">Long Term </option>
								</select>
							</td>
						</tr>
						
						<tr>
							<td bgcolor="#afdf6b">Seeding:</td>
							
							<td>
								<select  style="width:100%;border:1px solid green;padding:5px;" id="seeding" name="estab">
									<option>-Select Seeding-</option>
									<option value="DIRECT-SEED">Direct</option>
									<option value="TRANSPLANT">Transplant</option>
								</select>
							</td>
						</tr>
						<tr>
							<td bgcolor="#afdf6b"><i id="trans2" style="display:none;">Seedbed Duration:</i></td>
							<td>
								<select name="sbdur" disabled="disable" style="width:94%;border:1px solid green;padding:5px;display:none;" id="SelectedDate">
								
								<?php
								for($i=14;$i<=21;$i++){
								
								echo "<option value=".$i.">".$i."</option>";
								
								}
								
								?>
								
								</select>
								
							</td>
						</tr>
						<tr>
							<td>
							</td>
							<td>
								<center>
								<input id="button" type="submit" value="START" name="simulate">
								</center>
							</td>
						</tr>
						</table> 
					</form>   
